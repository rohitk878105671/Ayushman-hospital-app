import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

const hospitalName = 'Ayushman Hospital & Haddi Hospital';
final money = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 2);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Configure with FlutterFire before running.
  runApp(const HospitalApp());
}

class HospitalApp extends StatelessWidget {
  const HospitalApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: hospitalName,
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: const Color(0xFF167D68), useMaterial3: true),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) {
        return const Scaffold(body: Center(child: CircularProgressIndicator()));
      }
      return snap.data == null ? const LoginPage() : const DashboardPage();
    },
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;
  String? error;
  Future<void> login(bool create) async {
    setState(() { busy = true; error = null; });
    try {
      if (create) {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
      }
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message ?? e.code);
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420),
      child: Padding(padding: const EdgeInsets.all(24), child: Column(
        mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.local_hospital, size: 54, color: Color(0xFF167D68)),
          const SizedBox(height: 12),
          Text(hospitalName, textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 24),
          TextField(controller: email, keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(labelText: 'Email / ईमेल', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: password, obscureText: true,
            decoration: const InputDecoration(labelText: 'Password / पासवर्ड', border: OutlineInputBorder())),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 10),
            child: Text(error!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 16),
          FilledButton(onPressed: busy ? null : () => login(false),
            child: Text(busy ? 'Please wait…' : 'Login / लॉगिन')),
          TextButton(onPressed: busy ? null : () => login(true),
            child: const Text('Create staff account / नया स्टाफ अकाउंट')),
          const Text('Only authorized hospital staff should have accounts.',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.grey)),
        ],
      )),
    )),
  );
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    final db = FirebaseFirestore.instance;
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day);
    final end = start.add(const Duration(days: 1));
    return Scaffold(
      appBar: AppBar(title: const Text('Hospital Dashboard')),
      drawer: Drawer(child: ListView(children: [
        DrawerHeader(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.end, children: [
            const Icon(Icons.local_hospital, size: 36),
            Text(hospitalName, style: const TextStyle(fontWeight: FontWeight.bold)),
            const Text('Hindi + English'),
          ])),
        ListTile(leading: const Icon(Icons.people), title: const Text('Patients / मरीज'),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PatientsPage()))),
        ListTile(leading: const Icon(Icons.medication), title: const Text('Medicine Stock / दवा स्टॉक'),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StockPage()))),
        ListTile(leading: const Icon(Icons.point_of_sale), title: const Text('Medicine Sale / दवा बिक्री'),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SalePage()))),
        ListTile(leading: const Icon(Icons.receipt_long), title: const Text('Create Bill / बिल'),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BillPage()))),
        const Divider(),
        ListTile(leading: const Icon(Icons.logout), title: const Text('Logout / लॉगआउट'),
          onTap: () => FirebaseAuth.instance.signOut()),
      ])),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: db.collection('sales').where('createdAt', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
          .where('createdAt', isLessThan: Timestamp.fromDate(end)).snapshots(),
        builder: (context, snap) {
          final docs = snap.data?.docs ?? [];
          final total = docs.fold<double>(0, (s, d) => s + ((d.data()['total'] as num?)?.toDouble() ?? 0));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Text(hospitalName, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text(DateFormat('dd MMM yyyy').format(today), style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 16),
            Wrap(spacing: 12, runSpacing: 12, children: [
              _metric(context, 'Today medicine sale', money.format(total), Icons.currency_rupee),
              _metric(context, 'Sales entries', '${docs.length}', Icons.receipt),
            ]),
            const SizedBox(height: 18),
            const Text('Quick Actions', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 10),
            _action(context, 'Add Patient / मरीज जोड़ें', Icons.person_add, const PatientsPage()),
            _action(context, 'Add / View Medicine Stock', Icons.medication, const StockPage()),
            _action(context, 'Record Medicine Sale', Icons.shopping_cart, const SalePage()),
            _action(context, 'Create Patient Bill', Icons.receipt_long, const BillPage()),
            _action(context, 'Daily Report / दैनिक रिपोर्ट', Icons.bar_chart, const ReportPage()),
          ]);
        },
      ),
    );
  }
  Widget _metric(BuildContext c, String title, String value, IconData icon) => SizedBox(width: 165,
    child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start,
      children: [Icon(icon, color: Theme.of(c).colorScheme.primary), const SizedBox(height: 8),
        Text(value, style: Theme.of(c).textTheme.titleLarge), Text(title, style: const TextStyle(fontSize: 12))]))));
  Widget _action(BuildContext c, String title, IconData icon, Widget page) => Card(child: ListTile(
    leading: Icon(icon), title: Text(title), trailing: const Icon(Icons.chevron_right),
    onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => page))));
}

class PatientsPage extends StatefulWidget {
  const PatientsPage({super.key});
  @override
  State<PatientsPage> createState() => _PatientsPageState();
}
class _PatientsPageState extends State<PatientsPage> {
  final name = TextEditingController(), address = TextEditingController(), phone = TextEditingController();
  Future<void> add() async {
    if (name.text.trim().isEmpty) return;
    await FirebaseFirestore.instance.collection('patients').add({
      'name': name.text.trim(), 'address': address.text.trim(), 'phone': phone.text.trim(),
      'createdAt': FieldValue.serverTimestamp(), 'createdBy': FirebaseAuth.instance.currentUser?.uid,
    });
    name.clear(); address.clear(); phone.clear();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Patient saved / मरीज सेव हुआ')));
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Patients / मरीज')),
    floatingActionButton: FloatingActionButton.extended(onPressed: () => showDialog(context: context,
      builder: (_) => AlertDialog(title: const Text('Add Patient / मरीज जोड़ें'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Patient name / मरीज का नाम')),
          TextField(controller: address, decoration: const InputDecoration(labelText: 'Address / पता')),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile / मोबाइल')),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () async { await add(); if (context.mounted) Navigator.pop(context); }, child: const Text('Save'))])),
      icon: const Icon(Icons.add), label: const Text('Add Patient')),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('patients').orderBy('createdAt', descending: true).snapshots(),
      builder: (c, s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.docs.isEmpty) return const Center(child: Text('No patients yet / अभी मरीज नहीं हैं'));
        return ListView(children: s.data!.docs.map((d) {
          final x = d.data();
          return ListTile(leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text(x['name'] ?? ''), subtitle: Text('${x['address'] ?? ''}\n${x['phone'] ?? ''}'));
        }).toList());
      }),
  );
}

class StockPage extends StatefulWidget {
  const StockPage({super.key});
  @override
  State<StockPage> createState() => _StockPageState();
}
class _StockPageState extends State<StockPage> {
  final name = TextEditingController(), batch = TextEditingController(), qty = TextEditingController(),
    purchase = TextEditingController(), mrp = TextEditingController();
  Future<void> addStock() async {
    final q = int.tryParse(qty.text) ?? 0, p = double.tryParse(purchase.text) ?? -1, m = double.tryParse(mrp.text) ?? -1;
    if (name.text.trim().isEmpty || q <= 0 || p < 0 || m < 0) return;
    await FirebaseFirestore.instance.collection('medicines').add({
      'name': name.text.trim(), 'batch': batch.text.trim(), 'quantity': q,
      'purchaseRate': p, 'mrp': m, 'createdAt': FieldValue.serverTimestamp(),
    });
    name.clear(); batch.clear(); qty.clear(); purchase.clear(); mrp.clear();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Stock added / स्टॉक जुड़ा')));
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Medicine Stock / दवा स्टॉक')),
    floatingActionButton: FloatingActionButton.extended(onPressed: () => showDialog(context: context,
      builder: (_) => AlertDialog(title: const Text('Purchase Medicine / दवा खरीदें'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Medicine name / दवा का नाम')),
          TextField(controller: batch, decoration: const InputDecoration(labelText: 'Batch number / बैच नंबर')),
          TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantity / मात्रा')),
          TextField(controller: purchase, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Purchase rate per unit / खरीद दर')),
          TextField(controller: mrp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'MRP per unit')),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () async { await addStock(); if (context.mounted) Navigator.pop(context); }, child: const Text('Save Purchase'))])),
      icon: const Icon(Icons.add), label: const Text('Add Purchase')),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('medicines').orderBy('name').snapshots(),
      builder: (c, s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final docs = s.data!.docs;
        final cost = docs.fold<double>(0, (v,d) => v + ((d['quantity'] as num).toDouble() * (d['purchaseRate'] as num).toDouble()));
        final retail = docs.fold<double>(0, (v,d) => v + ((d['quantity'] as num).toDouble() * (d['mrp'] as num).toDouble()));
        return Column(children: [
          Padding(padding: const EdgeInsets.all(12), child: Row(children: [
            Expanded(child: Text('Stock purchase value\\n${money.format(cost)}')),
            Expanded(child: Text('Stock MRP value\\n${money.format(retail)}')),
          ])),
          Expanded(child: ListView(children: docs.map((d) {
            final x = d.data();
            return ListTile(leading: const Icon(Icons.medication),
              title: Text(x['name'] ?? ''), subtitle: Text('Batch: ${x['batch'] ?? '-'} | Qty: ${x['quantity']}\\nPurchase: ${money.format((x['purchaseRate'] as num).toDouble())} | MRP: ${money.format((x['mrp'] as num).toDouble())}'));
          }).toList())),
        ]);
      }),
  );
}

class SalePage extends StatefulWidget {
  const SalePage({super.key});
  @override
  State<SalePage> createState() => _SalePageState();
}
class _SalePageState extends State<SalePage> {
  String? selected;
  final qty = TextEditingController(text: '1');
  Future<void> sell(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) async {
    final q = int.tryParse(qty.text) ?? 0;
    final matches = docs.where((d) => d.id == selected).toList();
    if (matches.isEmpty || q <= 0) return;
    final doc = matches.first;
    final db = FirebaseFirestore.instance;
    await db.runTransaction((tx) async {
      final ref = db.collection('medicines').doc(doc.id);
      final fresh = await tx.get(ref);
      final stock = (fresh.data()?['quantity'] as num?)?.toInt() ?? 0;
      if (stock < q) throw Exception('Insufficient stock / स्टॉक कम है');
      final rate = (fresh.data()?['mrp'] as num).toDouble();
      final total = rate * q;
      tx.update(ref, {'quantity': stock - q});
      final saleRef = db.collection('sales').doc();
      tx.set(saleRef, {'medicineId': doc.id, 'medicineName': fresh.data()?['name'],
        'quantity': q, 'unitPrice': rate, 'total': total,
        'createdAt': FieldValue.serverTimestamp(), 'createdBy': FirebaseAuth.instance.currentUser?.uid});
    });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sale saved; stock reduced / बिक्री सेव, स्टॉक कम हुआ')));
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Medicine Sale / दवा बिक्री')),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('medicines').orderBy('name').snapshots(),
      builder: (c,s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final docs = s.data!.docs;
        return Padding(padding: const EdgeInsets.all(16), child: Column(children: [
          DropdownButtonFormField<String>(value: selected, isExpanded: true,
            decoration: const InputDecoration(labelText: 'Select medicine / दवा चुनें'),
            items: docs.map((d) => DropdownMenuItem(value: d.id, child: Text('${d['name']} (Stock: ${d['quantity']})'))).toList(),
            onChanged: (v) => setState(() => selected = v)),
          TextField(controller: qty, keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Quantity sold / बिक्री मात्रा')),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: () async {
            try { await sell(docs); } catch(e) {
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
            }
          }, icon: const Icon(Icons.check), label: const Text('Complete Sale / बिक्री सेव करें')),
        ]));
      }),
  );
}

class BillPage extends StatefulWidget {
  const BillPage({super.key});
  @override
  State<BillPage> createState() => _BillPageState();
}
class _BillPageState extends State<BillPage> {
  final patient = TextEditingController(), address = TextEditingController(), description = TextEditingController(),
    amount = TextEditingController();
  Future<void> createBill() async {
    final a = double.tryParse(amount.text) ?? 0;
    if (patient.text.trim().isEmpty || a <= 0) return;
    final ref = await FirebaseFirestore.instance.collection('bills').add({
      'patientName': patient.text.trim(), 'address': address.text.trim(),
      'description': description.text.trim(), 'total': a, 'paid': 0, 'createdAt': FieldValue.serverTimestamp(),
    });
    final doc = pw.Document();
    doc.addPage(pw.Page(build: (_) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
      pw.Text(hospitalName, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
      pw.SizedBox(height: 8), pw.Text('Patient Bill / मरीज बिल'),
      pw.Divider(), pw.Text('Bill ID: ${ref.id}'), pw.Text('Patient: ${patient.text}'),
      pw.Text('Address: ${address.text}'), pw.Text('Details: ${description.text}'),
      pw.SizedBox(height: 20), pw.Text('Total: ${money.format(a)}', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
    ])));
    await Printing.layoutPdf(onLayout: (_) async => doc.save());
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bill saved / बिल सेव हुआ')));
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Create Bill / बिल बनाएं')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      TextField(controller: patient, decoration: const InputDecoration(labelText: 'Patient name / मरीज का नाम')),
      TextField(controller: address, decoration: const InputDecoration(labelText: 'Address / पता')),
      TextField(controller: description, decoration: const InputDecoration(labelText: 'Bill details / बिल विवरण')),
      TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Total amount / कुल रकम')),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: createBill, icon: const Icon(Icons.picture_as_pdf), label: const Text('Save + Print / PDF')),
    ]),
  );
}

class ReportPage extends StatelessWidget {
  const ReportPage({super.key});
  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day);
    final end = start.add(const Duration(days: 1));
    return Scaffold(appBar: AppBar(title: const Text('Daily Report / दैनिक रिपोर्ट')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('sales').where('createdAt', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
          .where('createdAt', isLessThan: Timestamp.fromDate(end)).snapshots(),
        builder: (c,s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final docs = s.data!.docs;
          final total = docs.fold<double>(0, (v,d) => v + ((d['total'] as num).toDouble()));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Text('Date: ${DateFormat('dd MMM yyyy').format(now)}'),
            Text('Medicine sale total: ${money.format(total)}', style: Theme.of(context).textTheme.titleLarge),
            Text('Number of sale entries: ${docs.length}'),
            const Divider(),
            ...docs.map((d) => ListTile(title: Text(d['medicineName'] ?? ''),
              subtitle: Text('Qty: ${d['quantity']} × ${money.format((d['unitPrice'] as num).toDouble())}'),
              trailing: Text(money.format((d['total'] as num).toDouble())))),
          ]);
        }),
    );
  }
}
