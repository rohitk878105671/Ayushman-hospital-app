# Ayushman Hospital & Haddi Hospital — Android starter

This is a Flutter + Firebase starter project for a multi-mobile hospital workflow.

## Included in this first starter
- Email/password staff sign-in
- Shared patient records (name, address, mobile)
- Medicine purchase/stock entry (quantity, purchase rate, MRP, batch)
- Stock value at purchase rate and at MRP
- Medicine sale with Firestore transaction; stock decreases and insufficient stock is blocked
- Daily medicine sales report
- Basic patient bill saved to cloud and printed/exported as PDF

## Important limitations (not production-ready yet)
- This is source code, not an installed APK. It must be configured, built, tested, and signed.
- Bill entry is currently a basic single-total bill; itemized services, discounts, tax settings, payments, due balance, refunds, and bill numbering need the next development pass.
- Sales are recorded at MRP in this starter. Add actual selling price/discount controls before real use.
- Purchase entries currently add stock as a new medicine record. Batch-wise stock consolidation, expiry alerts, supplier ledger, returns, and purchase invoices are next steps.
- Firestore starter rules allow any authenticated account to read/write all app data. Do NOT use real patient data until proper hospital membership/role-based security rules and privacy review are implemented.
- No offline conflict resolution or local cache workflow has been configured.

## Setup
1. Install Flutter SDK and Android Studio.
2. Create a Firebase project for the hospital.
3. Enable **Authentication → Email/Password**.
4. Create a Cloud Firestore database.
5. Install FlutterFire CLI and run:
   `dart pub global activate flutterfire_cli`
   `flutterfire configure`
   Select your Firebase project and Android app. This generates `lib/firebase_options.dart`.
6. Update `lib/main.dart`: replace `await Firebase.initializeApp()` with
   `await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);`
   and add `import 'firebase_options.dart';`
7. Apply `firestore.rules` only after replacing the starter rules with reviewed role-based rules.
8. Run:
   `flutter pub get`
   `flutter run`
9. Create staff accounts only for authorized hospital employees.

## Android package id
Choose a permanent application id (for example `in.ayushmanhospital.manager`) before publishing. It should be registered in Firebase and Android Gradle configuration.

## Data collections
- `patients`
- `medicines`
- `sales`
- `bills`

Use synthetic/test data only until security, backup, and consent workflows are reviewed.
